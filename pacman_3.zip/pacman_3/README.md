
This version of ping pong uses the first design of Entity-Component that we have done in class.

The SDLGame class is not a singleton.
